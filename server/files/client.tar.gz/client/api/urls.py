from . import views
from django.urls import path,include

urlpatterns = [

   path('', views.Heartbeat.as_view(), name='heartbeat'),
   path('scan/', views.Scan.as_view(), name="Scan"),  

]