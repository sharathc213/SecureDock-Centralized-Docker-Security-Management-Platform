from rest_framework.views import APIView
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated
import subprocess
from django.http import JsonResponse
import os
from django.conf import settings




class Heartbeat(APIView):
    def get(self, request):

        return JsonResponse({'status': 'online'})


class Scan(APIView):
    permission_classes = [IsAuthenticated]
    # @method_decorator(csrf_exempt)  # Disable CSRF protection for this view
    def dispatch(self, request, *args, **kwargs):
        # Call the parent dispatch method to handle the request
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        # Path to the Bash script
        script_directory = os.path.join(settings.BASE_DIR, 'docker')
        script_path = os.path.join(settings.BASE_DIR,'docker','docker-bench-security.sh')  # Update with the actual path
        os.chdir(script_directory)
        process = subprocess.Popen(['/bin/bash', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        if process.returncode == 0:
            json_file_path = os.path.join(settings.BASE_DIR,'docker','log','docker-bench-security.log.json')  # Update with the actual path
            if os.path.exists(json_file_path):
              with open(json_file_path, 'r') as file:
                json_data = file.read()
              return JsonResponse(json_data, safe=False)
        else:
            return JsonResponse({'error': stderr.decode('utf-8')}, status=500)



